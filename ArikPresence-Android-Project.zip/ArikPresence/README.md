# ArikPresence

Android-only custom Discord Rich Presence app using the same Android IPC approach as LastWave Native.

## Build
Open this folder in Android Studio (JDK 17, Android SDK 35), allow Gradle sync, then Build > Build APK(s).

## Setup
1. Create an application in the Discord Developer Portal: https://discord.com/developers/applications
2. Copy its Application ID into ArikPresence.
3. Install/open Discord Android and sign in.
4. Enter your activity fields and tap Start.

Image fields accept HTTPS URLs. Discord may not resolve arbitrary URLs on every client; test with artwork URLs reachable without authentication.

## Technical note
The transport follows LastWave Native's `DiscordIpcTransport`: it discovers Discord's exported `com.discord.socialsdk.rpc.IDiscordRpcService`, binds with an explicit component, calls `IDiscordRpcService.connect(applicationId, "1", callback)`, and sends a `SET_ACTIVITY` JSON frame over `IDiscordRpcConnection`.

This is an unofficial integration point and can stop working if Discord changes its Android service or restricts access. The project has not been device-tested in this environment.

## Source and license
The Android Binder RPC interface and transport design are based on LastWave Native:
https://github.com/Clash-Projects/LastWave-Native

LastWave Native is GPL-3.0. See `LICENSE-LASTWAVE` for the license text. This project is distributed under GPL-3.0 because it incorporates/derives from that implementation.
