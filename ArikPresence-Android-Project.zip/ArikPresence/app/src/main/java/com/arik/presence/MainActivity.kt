package com.arik.presence

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151922)
private val Accent = Color(0xFF9B8CFF)

class MainActivity : ComponentActivity() {
    private lateinit var rpc: DiscordIpcTransport
    private var connected by mutableStateOf(false)
    private var message by mutableStateOf("ready")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("arikpresence", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onBackground = Color.White, onSurface = Color.White
            )) {
                var appId by remember { mutableStateOf(prefs.getString("appId", "") ?: "") }
                var activity by remember { mutableStateOf(prefs.getString("activity", "Playing a game") ?: "") }
                var details by remember { mutableStateOf(prefs.getString("details", "Exploring the world") ?: "") }
                var state by remember { mutableStateOf(prefs.getString("state", "In a session") ?: "") }
                var largeImage by remember { mutableStateOf(prefs.getString("largeImage", "") ?: "") }
                var largeText by remember { mutableStateOf(prefs.getString("largeText", "") ?: "") }
                var smallImage by remember { mutableStateOf(prefs.getString("smallImage", "") ?: "") }
                var smallText by remember { mutableStateOf(prefs.getString("smallText", "") ?: "") }
                var buttonLabel by remember { mutableStateOf(prefs.getString("buttonLabel", "") ?: "") }
                var buttonUrl by remember { mutableStateOf(prefs.getString("buttonUrl", "") ?: "") }
                Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp)) {
                    Text("arikpresence", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Text("custom discord activity • android", color = Color.Gray)
                    Spacer(Modifier.height(22.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("LIVE PREVIEW", color = Accent, style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.height(8.dp))
                            Text(activity.ifBlank { "Activity name" }, fontWeight = FontWeight.Bold)
                            Text(details.ifBlank { "Details" }, color = Color.LightGray)
                            Text(state.ifBlank { "State" }, color = Color.Gray)
                            if (buttonLabel.isNotBlank()) Text("［$buttonLabel］", color = Accent)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Field("Discord Application ID", appId, { appId = it }, "Create an app at discord.com/developers")
                    Field("Activity name", activity, { activity = it })
                    Field("Details", details, { details = it })
                    Field("State", state, { state = it })
                    Text("ARTWORK", color = Accent, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
                    Field("Large image URL", largeImage, { largeImage = it }, "https://…")
                    Field("Large image tooltip", largeText, { largeText = it })
                    Field("Small image URL", smallImage, { smallImage = it }, "https://…")
                    Field("Small image tooltip", smallText, { smallText = it })
                    Text("BUTTON (OPTIONAL)", color = Accent, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
                    Field("Button label", buttonLabel, { buttonLabel = it })
                    Field("Button URL", buttonUrl, { buttonUrl = it }, "https://…")
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {
                            prefs.edit().putString("appId", appId).putString("activity", activity)
                                .putString("details", details).putString("state", state)
                                .putString("largeImage", largeImage).putString("largeText", largeText)
                                .putString("smallImage", smallImage).putString("smallText", smallText)
                                .putString("buttonLabel", buttonLabel).putString("buttonUrl", buttonUrl).apply()
                            lifecycleScope.launch {
                                message = "connecting…"
                                val result = withContext(Dispatchers.IO) {
                                    DiscordIpcTransport.connectOrNull(this@MainActivity, appId.trim())
                                }
                                if (result == null) {
                                    connected = false
                                    message = "couldn't connect — open Discord and try again"
                                } else {
                                    rpc = result
                                    val sent = withContext(Dispatchers.IO) {
                                        rpc.setActivity(appId, activity, details, state, largeImage, largeText, smallImage, smallText, buttonLabel, buttonUrl)
                                    }
                                    connected = sent
                                    message = if (sent) "presence sent" else "send failed"
                                }
                            }
                        }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Start")
                        }
                        OutlinedButton(onClick = {
                            lifecycleScope.launch(Dispatchers.IO) {
                                if (::rpc.isInitialized) rpc.close()
                                withContext(Dispatchers.Main) { connected = false; message = "stopped" }
                            }
                        }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Stop, null); Spacer(Modifier.width(6.dp)); Text("Stop")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text((if (connected) "● " else "○ ") + message, color = if (connected) Color(0xFF71D6A0) else Color.Gray)
                    Spacer(Modifier.height(28.dp))
                    Text("Note: Discord must be installed and signed in. Rich Presence support depends on Discord's Android RPC service and may vary by version.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    override fun onDestroy() {
        if (::rpc.isInitialized) rpc.close()
        super.onDestroy()
    }
}

@Composable
private fun Field(label: String, value: String, onValue: (String) -> Unit, hint: String = "") {
    OutlinedTextField(
        value = value, onValueChange = onValue, label = { Text(label) },
        placeholder = { if (hint.isNotBlank()) Text(hint) },
        modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp),
        singleLine = true, shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF303746),
            focusedLabelColor = Accent
        )
    )
}
