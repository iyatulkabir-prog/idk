package com.arik.presence

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.util.Log
import com.discord.socialsdk.rpc.IDiscordRpcCallback
import com.discord.socialsdk.rpc.IDiscordRpcConnection
import com.discord.socialsdk.rpc.IDiscordRpcService
import java.util.UUID
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import kotlin.coroutines.resume

/**
 * Android Discord RPC transport following LastWave Native's implementation:
 * bind to Discord's exported Social SDK RPC service, call AIDL connect(),
 * then send the desktop-compatible SET_ACTIVITY frame over the returned Binder.
 *
 * LastWave Native source: https://github.com/Clash-Projects/LastWave-Native
 * Its GPL-3.0 license is included in this project.
 */
class DiscordIpcTransport private constructor(
    private val context: Context,
    private val serviceConnection: ServiceConnection,
    private val rpcConnection: IDiscordRpcConnection
) {
    @Volatile private var closed = false
    private fun isOpen() = !closed && runCatching { rpcConnection.asBinder().isBinderAlive }.getOrDefault(false)

    fun setActivity(
        appId: String, name: String, details: String, state: String,
        largeImage: String, largeText: String, smallImage: String, smallText: String,
        buttonLabel: String, buttonUrl: String
    ): Boolean {
        if (!isOpen()) return false
        val activity = JSONObject().apply {
            put("type", 0)
            put("name", name.take(128))
            if (details.isNotBlank()) put("details", details.take(128))
            if (state.isNotBlank()) put("state", state.take(128))
            val assets = JSONObject()
            if (largeImage.isNotBlank()) assets.put("large_image", largeImage)
            if (largeText.isNotBlank()) assets.put("large_text", largeText.take(128))
            if (smallImage.isNotBlank()) assets.put("small_image", smallImage)
            if (smallText.isNotBlank()) assets.put("small_text", smallText.take(128))
            if (assets.length() > 0) put("assets", assets)
            if (buttonLabel.isNotBlank() && buttonUrl.startsWith("https://")) {
                put("buttons", org.json.JSONArray().put(JSONObject().put("label", buttonLabel.take(32)).put("url", buttonUrl)))
            }
            put("instance", true)
        }
        val frame = JSONObject().apply {
            put("cmd", "SET_ACTIVITY")
            put("args", JSONObject().put("pid", Process.myPid()).put("activity", activity))
            put("nonce", UUID.randomUUID().toString())
        }.toString()
        return runCatching { rpcConnection.sendFrame(frame); true }
            .onFailure { Log.w(TAG, "Discord sendFrame failed", it) }.getOrDefault(false)
    }

    fun clearActivity() {
        if (!isOpen()) return
        val frame = JSONObject().apply {
            put("cmd", "SET_ACTIVITY")
            put("args", JSONObject().put("pid", Process.myPid()).put("activity", JSONObject.NULL))
            put("nonce", UUID.randomUUID().toString())
        }.toString()
        runCatching { rpcConnection.sendFrame(frame) }
    }

    fun close() {
        if (closed) return
        runCatching { clearActivity() }
        closed = true
        runCatching { rpcConnection.disconnect() }
        runCatching { context.unbindService(serviceConnection) }
    }

    companion object {
        private const val TAG = "ArikPresenceRPC"
        private const val RPC_ACTION = "com.discord.socialsdk.rpc.IDiscordRpcService"
        private const val RPC_VERSION = "1"
        private val DISCORD_PACKAGES = listOf("com.discord", "com.discord.canary", "com.discord.ptb", "com.discord.debug")

        private data class Bound(val binder: IBinder, val connection: ServiceConnection)

        private fun findRpcComponent(context: Context): ComponentName? {
            val pm = context.packageManager
            for (pkg in DISCORD_PACKAGES) {
                val services = runCatching {
                    if (Build.VERSION.SDK_INT >= 33)
                        pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(PackageManager.GET_SERVICES.toLong())).services
                    else {
                        @Suppress("DEPRECATION")
                        pm.getPackageInfo(pkg, PackageManager.GET_SERVICES).services
                    }
                }.getOrNull()
                services?.firstOrNull { it.exported && it.name.contains("rpc", true) }?.let {
                    return ComponentName(pkg, it.name)
                }
                val intent = Intent(RPC_ACTION).setPackage(pkg)
                val queried = runCatching {
                    if (Build.VERSION.SDK_INT >= 33)
                        pm.queryIntentServices(intent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong()))
                    else {
                        @Suppress("DEPRECATION")
                        pm.queryIntentServices(intent, PackageManager.MATCH_ALL)
                    }
                }.getOrNull()
                queried?.firstOrNull()?.serviceInfo?.let { return ComponentName(it.packageName, it.name) }
            }
            return null
        }

        suspend fun connectOrNull(context: Context, appId: String, timeoutMs: Long = 3000L): DiscordIpcTransport? {
            if (appId.toLongOrNull() == null) return null
            val component = findRpcComponent(context) ?: return null
            val app = context.applicationContext
            val intent = Intent(RPC_ACTION).setComponent(component)
            val bound = withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<Bound?> { continuation ->
                    val connection = object : ServiceConnection {
                        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                            if (continuation.isActive) continuation.resume(binder?.let { Bound(it, this) })
                        }
                        override fun onServiceDisconnected(name: ComponentName?) {}
                        override fun onBindingDied(name: ComponentName?) { if (continuation.isActive) continuation.resume(null) }
                        override fun onNullBinding(name: ComponentName?) { if (continuation.isActive) continuation.resume(null) }
                    }
                    val ok = runCatching { app.bindService(intent, connection, Context.BIND_AUTO_CREATE) }.getOrDefault(false)
                    if (!ok) { continuation.resume(null); return@suspendCancellableCoroutine }
                    continuation.invokeOnCancellation { runCatching { app.unbindService(connection) } }
                }
            } ?: return null

            val callback = object : IDiscordRpcCallback.Stub() {
                override fun onFrame(frame: String?) {}
                override fun onClose(code: Int, message: String?) { Log.d(TAG, "Discord RPC closed: $code $message") }
            }
            val rpc = runCatching {
                IDiscordRpcService.Stub.asInterface(bound.binder).connect(appId.toLong(), RPC_VERSION, callback)
            }.getOrNull()
            if (rpc == null) {
                runCatching { app.unbindService(bound.connection) }
                return null
            }
            return DiscordIpcTransport(app, bound.connection, rpc)
        }
    }
}
